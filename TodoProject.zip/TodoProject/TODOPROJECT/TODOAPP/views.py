from django.shortcuts import render,redirect
from . models import Task
from . forms import ToDoForm
# Create your views here.

def add(request):
    tasks=Task.objects.all()
    if request.method=='POST':
        Name=request.POST.get('task','')
        priority=request.POST.get('Priority','')
        date=request.POST.get('date','')
        task=Task(Name=Name,priority=priority,date=date)
        task.save()
    return render(request,'home.html',{'tasks':tasks})


# function for showing values in details.html page
# def details(request):
#     task=Task.objects.all()
#     return render(request,'details.html',{'task':task})

def delete(request,task_id):
    task=Task.objects.get(id=task_id)
    if request.method=='POST':
        task.delete()
        return redirect('/')

    return render(request,'delete.html')

def update(request,task_id):
    task=Task.objects.get(id=task_id)
    f=ToDoForm(request.POST or None,instance=task)
    if f.is_valid():
        f.save()
        return redirect('/')
    return render(request,'update.html',{'f':f,'task':task})
     

